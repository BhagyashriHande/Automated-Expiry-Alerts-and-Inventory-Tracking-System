document.addEventListener("DOMContentLoaded", function () {
    const savedInventory = JSON.parse(localStorage.getItem("inventory")) || [];
    savedInventory.forEach(item => addRowToTable(item.productName, item.Price, item.quantity, item.expiryDate));
});

function addRowToTable(productName, Price, quantity, expiryDate) {
    const table = document.getElementById("inventoryTable");
    const newRow = table.insertRow();

    newRow.innerHTML = `
        <td>${productName}</td>
        <td>${Price}</td>
        <td>${quantity}</td>
        <td>${expiryDate}</td>
        <td>
            <button class="btn btn-danger btn-sm delete-item">Delete</button>
        </td>
    `;

    newRow.querySelector(".delete-item").addEventListener("click", function () {
        this.closest("tr").remove();
        saveInventory();
    });
}

function saveInventory() {
    const table = document.getElementById("inventoryTable");
    const rows = table.getElementsByTagName("tr");
    const inventory = [];

    for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName("td");
        inventory.push({
            productName: cells[0].innerText,
            Price: cells[1].innerText,
            quantity: cells[2].innerText,
            expiryDate: cells[3].innerText
        });
    }

    localStorage.setItem("inventory", JSON.stringify(inventory));
}

document.getElementById("addItem").addEventListener("click", function () {
    const productName = document.getElementById("productName").value.trim();
    const price = document.getElementById("price").value.trim();
    const quantity = document.getElementById("quantity").value.trim();
    const expiryDate = document.getElementById("expiryDate").value.trim();

    if (productName && price && quantity && expiryDate) {
        addRowToTable(productName, price, quantity, expiryDate);
        saveInventory();
        document.getElementById("inventoryForm").reset(); // Clear the form
    } else {
        alert("Please fill in all fields before adding an item.");
    }
});

